package theatre.sys;
import javax.swing.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Arrays;

public class ViewReceiptFrame extends JFrame {

    ViewReceiptFrame(JFrame previousFrame) {
        // Modify the constructor to accept a JFrame argument
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("View Receipt");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setSize(400, 400);
            frame.setLocationRelativeTo(null);

            frame.setVisible(true);
        });
    }

    // calling this to seat booking frame

    public static void handleReceipt(String name, String movie, String seat, String seatsToBook, int totalAmount) {
        DecimalFormat decimalFormat = new DecimalFormat("#.##");

        StringBuilder receipt = new StringBuilder();
        receipt.append("*** Theatre Receipt ***\n");
        receipt.append("Customer Name: ").append(name).append("\n");
        receipt.append("Movie Name: ").append(movie).append("\n");
        receipt.append("Seat Number: ").append(seat).append("\n");
        receipt.append("Seats to Book: ").append(seatsToBook).append("\n");
        receipt.append("Total Amount: $").append(decimalFormat.format(totalAmount)).append("\n");
        receipt.append("*************");

        JOptionPane.showMessageDialog(null, receipt.toString(), "Receipt", JOptionPane.INFORMATION_MESSAGE);

        // condition for user if they want to save the receipt
        int saveOption = JOptionPane.showConfirmDialog(null, "Do you want to save this receipt?", "Save Receipt", JOptionPane.YES_NO_OPTION);
        if (saveOption == JOptionPane.YES_OPTION) {
            saveReceiptToFile(receipt.toString(), name);
        }
    }

    private static void saveReceiptToFile(String receipt, String name) {
        try {
            // Modified: Create a new file with a unique name based on the first character of the customer's name and timestamp
            char firstChar = name.isEmpty() ? 'A' : name.toUpperCase().charAt(0);
            String fileName = "receipt_" + firstChar + "_" + System.currentTimeMillis() + ".txt";

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
                writer.write(receipt);
                JOptionPane.showMessageDialog(null, "Receipt saved to '" + fileName + "'", "Receipt Saved", JOptionPane.INFORMATION_MESSAGE);

                // Modified: Apply binary search
                char searchChar = fileName.charAt(8);  // Assuming the character is at index 8 in the filename
                searchFileByName(searchChar);

            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error saving receipt to file", "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();  // Handle the exception according to your application's needs
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void searchFileByName(char searchChar) {
        // Modified: Assuming you have an array of file names
        String[] fileNames = {"receipt_A.txt", "receipt_B.txt", "receipt_C.txt", /* ... */};

        // Modified: Sort the array
        Arrays.sort(fileNames);

        // Modified: Binary search
        int result = Arrays.binarySearch(fileNames, "receipt_" + searchChar + ".txt");

        if (result >= 0) {
            JOptionPane.showMessageDialog(null, "File found: " + fileNames[result], "File Found", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "File not found", "File Not Found", JOptionPane.WARNING_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame testFrame = new JFrame("Testing View Receipt Frame");
            testFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            testFrame.setSize(400, 400);
            testFrame.setLocationRelativeTo(null);

            JButton receiptBtn = new JButton("View Receipt");
            receiptBtn.addActionListener(e -> {
                testFrame.setVisible(false);
                ViewReceiptFrame receiptFrame = new ViewReceiptFrame(testFrame);
                receiptFrame.setVisible(true);
            });

            JPanel testPanel = new JPanel();
            testPanel.add(receiptBtn);

            testFrame.setContentPane(testPanel);
            testFrame.setVisible(true);
        });
    }
}
