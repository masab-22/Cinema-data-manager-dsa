package theatre.sys;

import javax.swing.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Arrays;

// Frame to view and potentially save a receipt
public class ViewReceiptFrame extends JFrame {

    // Constructor for ViewReceiptFrame
    ViewReceiptFrame(JFrame previousFrame) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("View Receipt");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setSize(400, 400);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }

    // Method to handle the creation and display of a receipt
    public static void handleReceipt(String name, String movie, String seat, String seatsToBook, int totalAmount) {
        // Formatting total amount
        DecimalFormat decimalFormat = new DecimalFormat("#.##");

        // Build receipt content
        StringBuilder receipt = new StringBuilder();
        receipt.append("*** Theatre Receipt ***\n");
        receipt.append("Customer Name: ").append(name).append("\n");
        receipt.append("Movie Name: ").append(movie).append("\n");
        receipt.append("Seat Number: ").append(seat).append("\n");
        receipt.append("Seats to Book: ").append(seatsToBook).append("\n");
        receipt.append("Total Amount: $").append(decimalFormat.format(totalAmount)).append("\n");
        receipt.append("*************");

        // Display receipt
        JOptionPane.showMessageDialog(null, receipt.toString(), "Receipt", JOptionPane.INFORMATION_MESSAGE);

        // Ask user to save the receipt
        int saveOption = JOptionPane.showConfirmDialog(null, "Do you want to save this receipt?", "Save Receipt", JOptionPane.YES_NO_OPTION);
        if (saveOption == JOptionPane.YES_OPTION) {
            saveReceiptToFile(receipt.toString(), name);
        }
    }

    // Method to save the receipt to a file
    private static void saveReceiptToFile(String receipt, String name) {
        try {
            // Extract the first character from the  input of username
            char firstChar = name.isEmpty() ? 'A' : name.toUpperCase().charAt(0);

            // this is  interesting part for saving first character from username will be picked uppercased and then merged with timestamp Returns the current time
            // in milliseconds which will be used to save it as unique name .
            String fileName = "receipt_" + firstChar + "_" + System.currentTimeMillis() + ".txt";

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
                // Write the receipt content to the file
                writer.write(receipt);
                JOptionPane.showMessageDialog(null, "Receipt saved to '" + fileName + "'", "Receipt Saved", JOptionPane.INFORMATION_MESSAGE);

                // Applying binary search
                char searchChar = fileName.charAt(8);  // Assuming the character is at index 8 in the filename
                searchFileByName(searchChar);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error saving receipt to file", "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to search for a file by name
    private static void searchFileByName(char searchChar) {
        //  file names
        String[] fileNames = {"receipt_A.txt", "receipt_B.txt", "receipt_C.txt", /* ... */};

        // Sort the array using quicksort
        Arrays.sort(fileNames);

        // Binary search to find the file
        int result = Arrays.binarySearch(fileNames, "receipt_" + searchChar + ".txt");

        // Display search result
        if (result >= 0) {
            JOptionPane.showMessageDialog(null, "File found: " + fileNames[result], "File Found", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "File not found", "File Not Found", JOptionPane.WARNING_MESSAGE);
        }
    }

    // Main method
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame testFrame = new JFrame("Testing View Receipt Frame");
            testFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            testFrame.setSize(400, 400);
            testFrame.setLocationRelativeTo(null);

            JButton receiptBtn = new JButton("View Receipt");
            receiptBtn.addActionListener(e -> {
                testFrame.setVisible(false);
                ViewReceiptFrame receiptFrame = new ViewReceiptFrame(testFrame);
                receiptFrame.setVisible(true);
            });

            JPanel testPanel = new JPanel();
            testPanel.add(receiptBtn);

            testFrame.setContentPane(testPanel);
            testFrame.setVisible(true);
        });
    }
}
