package theatre.sys;

public interface SeatClickListener {
}
